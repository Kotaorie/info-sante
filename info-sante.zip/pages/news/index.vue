<template>
    <div>
        <Header/>
        <h3 class="mt-5 titre ">Liste de nos infos :</h3>
        <Liste/>

    </div>
</template>

<script>

    export default {
      
      }

</script>

<style  scoped>
  .titre {
    width: fit-content;
    margin-left: 55vh;
  }

</style>